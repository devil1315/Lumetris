export type PositionOptionsType = 'auto' | 'top' | 'bottom';
//# sourceMappingURL=position-options-type.d.ts.map